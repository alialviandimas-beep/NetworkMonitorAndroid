
package com.example.networkmonitor

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.net.InetAddress
import java.net.Socket
import java.net.URL
import javax.net.ssl.HttpsURLConnection

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val text = findViewById<TextView>(R.id.textStatus)
        Thread {
            val result = StringBuilder()

            // ICMP / Reachability (non-root)
            try {
                val reachable = InetAddress.getByName("8.8.8.8").isReachable(3000)
                result.append("ICMP Reachable: $reachable\n")
            } catch (e: Exception) {
                result.append("ICMP Error: ${e.message}\n")
            }

            // TCP check
            try {
                Socket("google.com", 80).use { }
                result.append("TCP 80: OK\n")
            } catch (e: Exception) {
                result.append("TCP 80: FAIL\n")
            }

            // HTTP check
            try {
                val conn = URL("http://example.com").openConnection()
                conn.connect()
                result.append("HTTP: OK\n")
            } catch (e: Exception) {
                result.append("HTTP: FAIL\n")
            }

            // HTTPS check
            try {
                val conn = URL("https://example.com").openConnection() as HttpsURLConnection
                conn.connect()
                result.append("HTTPS: OK\n")
            } catch (e: Exception) {
                result.append("HTTPS: FAIL\n")
            }

            runOnUiThread {
                text.text = result.toString()
            }
        }.start()
    }
}
